const express = require('express');
const bodyParser = require('body-parser');
const app = express();
const sqlite3 = require('sqlite3').verbose();
const fs = require('fs');
const { render } = require('ejs');
const { sign } = require('crypto');

app.set('views', './views');
app.set('view engine', 'ejs'); 
app.use(bodyParser.urlencoded({ extended: true }));
app.use(express.static(__dirname + '/views'));


let db = new sqlite3.Database(':memory:', (err) => {
if (err) {
    return console.error(err.message);
}
console.log('Connected to the in-memory SQlite database.');
});

var name;
var user_id;

var CREATE_PRODUCT = "CREATE TABLE IF NOT EXISTS product"+
                "( product_id INTEGER PRIMARY KEY AUTOINCREMENT,"+
                "product_name TEXT NOT NULL, price FLOAT NOT NULL,"+
                "category TEXT, merchant TEXT, expiry TEXT NOT NULL,"+ 
                "stock INT NOT NULL, img TEXT)";

var CREATE_CART = "CREATE TABLE IF NOT EXISTS cart"+
                "( product_id INTEGER, product_name TEXT NOT NULL,"+
                "price FLOAT NOT NULL, qty INT NOT NULL, img TEXT," +
                "total_peritem FLOAT, total FLOAT )";

var CREATE_USER = "CREATE TABLE IF NOT EXISTS user"+
                "( user_id INTEGER PRIMARY KEY AUTOINCREMENT, "+
                "name TEXT NOT NULL, user_name TEXT NOT NULL, "+
                "password TEXT NOT NULL, status INT NOT NULL)";

var INSERT_DATA = "INSERT INTO product (product_name, price, category, merchant, expiry, stock, img) VALUES "+
                "('Carrot', 1.00, 'Vegetable','Ranch Farm', '26/11/2020', 20, 'images/carrot.jpg'), "+
                "('Red Chilli', 1.45, 'Vegetable', 'Ranch Farm', '20/11/2020', 20, 'images/red_chili.jpg'), "+
                "('Tomato', 1.89, 'Vegetable', 'Ranch Farm', '22/11/2020', 20, 'images/tomato.jpg'), "+
                "('Onion', 0.92, 'Vegetable', 'Ranch Farm', '25/11/2020', 20, 'images/onion.jpg'), "+
                "('Celery', 0.52, 'Vegetable', 'Ranch Farm', '20/11/2020', 20, 'images/celery.jpg');";


db.serialize(function() {
    db.run(CREATE_PRODUCT, function(err){
        if (err){
            console.log(err);
        }
        else{
            console.log('Create Table Product success');
        }
    });

    db.run(CREATE_CART, function(err){
        if (err){
            console.log(err);
        }
        else{
            console.log('Create Table Cart Success');
        }
    });

    db.run(CREATE_USER, function(err){
        if (err){
            console.log(err);
        }
        else{
            console.log('Create Table User Success');
        }
    });

    db.run(INSERT_DATA, function(err){
        if (err){
            console.log(err);
        }
        else{
            console.log('Insert Data Success');
        }
    });

});

app.get('/', (req, res) => {
    let key = req.query.search;
    if(key){
        console.log(key);
        let SHOW_TABLE = "SELECT * FROM product WHERE product_name LIKE '%"+key+"%'";
        db.all(SHOW_TABLE, function(err, rows) {
            if(!err){
                //res.send(JSON.stringify({"status": 200, "error": null, "response": rows}));
                console.log(rows);
                //const data = JSON.parse(rows);
                res.render('index', {rows, 'name':name});
            }
        })
    }
    else {
        let SHOW_TABLE = "SELECT * FROM product";
        db.all(SHOW_TABLE, function(err, rows) {
            if(!err){
                console.log(rows);
                res.render('index', {rows, 'name':name});
            }
        })
    }    
});

app.get('/inventory', (req, res)=>{
    let SHOW_TABLE = "SELECT * FROM product";
    db.all(SHOW_TABLE, function(err, rows) {
        if(!err){
            console.log(rows);
            res.render('inventory', {rows});
        }
    })
})

app.post('/inventory', (req, res) => {
    var id = req.body.inventory.id;
    var plus = req.body.inventory.stock;
    var current = req.body.inventory.current;
    var now = parseInt(current)+parseInt(plus);
    
    let ADD_STOCK="UPDATE product SET stock="+now+" WHERE product_id="+id;
    
    db.run(ADD_STOCK, function(err){
        if(err){
            console.log(err);
        }
        else{
            console.log("add stock success");
            res.redirect('/inventory');
        }
    })
})

app.post('/', (req, res) => {
    if(name==null){
        res.redirect("http://localhost:3000/sign-in");
    }
    else{
        console.log(req.body.cart.qty);
        console.log(req.body.cart.product);
        console.log(req.body.cart.price);
        var item = req.body.cart.price;
        var qty = req.body.cart.qty;
        var tot_item = item*qty;
        
        let ADD_CART="INSERT INTO cart (product_name, qty, price, img, total_peritem)"+
                    "VALUES ('"+req.body.cart.product+"',"+req.body.cart.qty+
                    ","+req.body.cart.price+",'"+req.body.cart.img+"',"+tot_item+")";
        
        db.run(ADD_CART, function(err){
            if(err){
                console.log(err);
            }
            else{
                res.status(204).send();
            }
        })
    }
    
})

app.get('/cart', (req,res)=>{
    let SHOW_CART="SELECT * FROM cart";
    db.all(SHOW_CART, function(err,cart){
        if(err){
            console.log(err);
        }
        else{
            res.render('cart', {cart, 'name':name});
        }
    })
})

app.post('/checkout', (req,res)=>{
    res.render('checkout');
})

app.get('/sign-up', (req, res) => {
    res.render('sign-up');
})

app.get('/sign-in', (req, res) => {
    res.render('sign-in', {user:null, pass:null});
})

app.post('/sign-in', (req, res) => {
    var username = req.body.user.user_name;
    var password = req.body.user.password;
    var user_json;
    var GET_USER = "SELECT user_id, name, password FROM user WHERE user_name='"+username+"'";

    db.all(GET_USER, function(err, user){
        var user_bool;
        var pass_bool;
        if(err){
            console.log(err);
        }
        else if(isEmptyObject(user)){
            console.log("usr"+user);
            user_bool = 0;
            res.render('sign-in', {user: false, pass: true});
        }
        else{
            console.log(user);
            user.forEach(b=>{
                console.log(b.password);
                if(b.password==password){
                    pass_bool = 1;
                }
                else
                    pass_bool = 0;
            })
            user_json = user;
            user_bool = 1;
        }
        console.log(user_bool);
        console.log(pass_bool);

        if (user_bool==1 && pass_bool==0) {
            res.render('sign-in', {user: true, pass: false});
        }
        else if(user_bool==1 && pass_bool==1){
            let CHANGE_STS="UPDATE user SET status=1 WHERE user_name='"+username+"'";
            db.run(CHANGE_STS, function(err){
                if(!err){

                    console.log("update status success");
                    user.forEach(a => {
                        name = a.name;
                        user_id = a.user_id;
                        console.log(name);
                        res.redirect("http://localhost:3000");
                    })
                }
            })
        }
    })
})

app.get('/log_out', (req, res) =>{
    let CHANGE_STS_OUT = "UPDATE user SET status=0 WHERE user_id="+user_id;
    db.run(CHANGE_STS_OUT, function(err){
        if(!err){
            name=null;
            res.redirect('http://localhost:3000');
        }
    })
})

app.post('/sign-up', (req, res) => {
    var name = req.body.user.name;
    var user = req.body.user.user_name;
    var pass = req.body.user.password;

    console.log(name);
    console.log(user);
    console.log(pass);

    let ADD_USER = "INSERT INTO user (name, user_name, password,status)"+
                " VALUES ('"+ name + "','" + user + "','" + pass + "',0)";
    db.run(ADD_USER, function(err){
        if (err) {
            console.log(err);
        }
        else
            console.log("ADD USER SUCCESS");
    })

    res.redirect("/");
})

app.listen(3000,() =>{
    console.log('Server started on port 3000');
});

function isEmptyObject(obj) {
    return !Object.keys(obj).length;
}
  